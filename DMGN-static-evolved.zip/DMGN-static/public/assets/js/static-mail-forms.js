/* Static-only expression-of-interest forms. No API, network call or storage. */
(function () {
  "use strict";
  document.querySelectorAll("[data-mailto-form]").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var status = form.querySelector("[data-form-status]");
      var trap = form.querySelector('input[name="website"]');
      if (trap && trap.value) return;
      if (!form.reportValidity()) return;
      var recipient = "contactdmgn@gmail.com";
      var subject = form.getAttribute("data-subject") || "DMGN enquiry";
      var fields = [];
      new FormData(form).forEach(function (value, key) {
        if (key !== "website") fields.push(key + ": " + String(value).trim());
      });
      if (status) {
        status.dataset.state = "ok";
        status.textContent = "Your email app should open with your details. Review the message and press Send to submit it to DMGN.";
      }
      window.location.href = "mailto:" + recipient +
        "?subject=" + encodeURIComponent(subject) +
        "&body=" + encodeURIComponent(fields.join("\\n"));
    });
  });
})();
