# DMGN static evolution

This update adds three static routes: `/ai-academy/`, `/fadukpe-youth-governance/`, and `/initiatives/`.

## Included changes
- Registered the three new pages in `scripts/build.js`, so the build generates their pretty-URL directories and includes them in `sitemap.xml`.
- Added a homepage initiative section and footer links.
- Added the AI Academy six-week curriculum and FAQ.
- Added the Fadukpe Youth Governance overview and membership-interest form.
- Added a reusable client-side `mailto:` form handler.
- Added matching styles using the existing DMGN design system.
- Added the three new routes to the Playwright audit route list.
- Updated the canonical site origin and Cloudflare custom-domain instructions to `www.deenimaiyaki.com.ng`.
- Updated deployment documentation to identify the actual GitHub repository as `deenimaiyaki/DMGN-static`.

## Architecture
No Worker, Pages Function, API route, server, database, external form service, or application storage was introduced. Forms validate in the browser and open the visitor's email client. Visitors must press Send themselves.

## Verification performed
- `npm run build`: passed; generated 17 pages plus sitemap, RSS feed, robots.txt and redirects.
- `node --check` on build, audit and site JavaScript files: passed.
- Static route checks: all 17 generated routes have one H1, title, description and canonical; all image alt/dimension checks and form-label checks passed.
- Internal local links checked: 25 unique links; no missing local targets.
- The full Playwright browser audit could not be run in this environment because the Playwright package was not available after dependency installation timed out. Run `npm ci` and `npm run audit` in a normal Node 18+ environment before production deployment.

## Before deployment
1. Confirm `www.deenimaiyaki.com.ng` is the production canonical domain.
2. Confirm the domain is attached to the correct Cloudflare Pages project.
3. Run `npm ci`, `npm run build`, and `npm run audit -- http://localhost:8787 ./shots`.
4. Preview the generated `public/` site and test the mailto forms on a device with an email client configured.
5. Deploy only after DMGN approves the content and domain configuration.
